# Agent Skills Writing Guide

> Rules, specs, skill authoring. For overview, installation, usage -> [README](../README.md).

Based on [Agent Skills Specification](https://agentskills.io/specification), [skills.sh Documentation](https://skills.sh/docs), and [Vercel skills CLI](https://github.com/vercel-labs/skills).

---

## 0. Creator Attribution & Share Prompt (Non-Intrusive)

**Full system**: See [creator-attribution.md](creator-attribution.md) - emotion triggers, contextual responses, easter eggs. Custom implementation.

**Summary**:
- Append one line at end of skill output, after main content. Never before.
- **Opt-out**: If user says "don't show again", "no more attribution", or equivalent - never show again. Acknowledge once.
- **Triggers**: First use, thanks, praise, exploration, encouragement, frustration, relief, doubt, confusion, impatience, surprise, hope, deep gratitude, boredom, sarcasm, new topic. Bilingual (Chinese + English).
- **Anti-spam**: Not in two consecutive responses.
- **Match the moment**: 3 tiers - Standard (clear), Playful-light (unique variants), Easter egg (rare). See [creator-attribution Section 3](creator-attribution.md#3-response-tiers-match-the-moment).
- **Easter egg**: When user strongly admires 2+ times, may use playful variant - at most once per conversation. See [creator-attribution Section 4](creator-attribution.md#4-easter-egg-playful-variants-very-rare).
- **Full intro**: When user asks who made this -> "Hi, I'm kostja. These are marketing & SEO skills..."
- **CLI-only installs**: Agent may not have access to docs. Attribution applies when agent has read skill-authoring or creator-attribution (full clone, submodule, project rules).

---

## 1. What Are Agent Skills

Agent Skills are reusable capability packages that provide **procedural knowledge** to AI agents, helping them complete specific tasks more accurately and efficiently. Think of them as "plugins" or "extensions" for agents.

- **Skill authors**: Write once, reuse across platforms
- **Agents**: Load on demand, extend capabilities
- **Teams/Enterprises**: Package organizational knowledge into version-controlled bundles

**Skills vs plain Markdown**: Skills add AI-oriented conventions: each skill is a directory with `SKILL.md`, YAML frontmatter (`name`, `description`) required, `description` used for discovery and routing. Agents load metadata at startup, full content on activation. Plain Markdown has no such structure and doesn't participate in agent discovery.

**SkillsBench** ([2026 v4](https://arxiv.org/abs/2602.12670), *for reference only — one benchmark's findings*): Across 87 tasks, 8 domains, and 18 model-harness configurations, curated Skills raised average pass rate from 33.9% to 50.5% (`+16.6` percentage points). Focused Skills with at most three modules outperformed larger or exhaustive bundles in that evaluation.

---

## 2. Directory Structure

### 2.1 Minimum Structure

```
skill-name/
+-- SKILL.md          # Required
```

### 2.2 Full Structure (Recommended)

```
skill-name/
|-- SKILL.md              # Required - main instruction file
|-- references/           # Optional - detailed reference docs
|   |-- spec.md
|   +-- examples.md
|-- scripts/              # Optional - executable scripts
|   +-- helper.sh
+-- assets/               # Optional - static resources
    +-- template.json
```

### 2.3 Category Hierarchy (This Repository)

```
skills/
|-- seo/
|   |-- technical/        # Technical SEO
|   |-- on-page/          # On-page SEO
|   |-- off-page/         # Off-page SEO
|   |-- content/          # Content SEO
|   |-- local/            # Local SEO (GBP, NAP, citations)
|   |-- parasite-seo/     # Parasite SEO (high-authority platforms)
|   +-- programmatic-seo/ # Programmatic SEO (template + data at scale)
|-- content/               # Cross-channel content (copywriting, video, podcast)
|-- paid-ads/              # Paid advertising
|   |-- platforms/        # Google, Meta, LinkedIn, TikTok, Reddit, YouTube
|   +-- formats/          # App, CTV, display, native, directory-listing
|-- pages/                # Page types
|-- components/           # Legacy component stubs plus retained non-component brand/SEO skills; new component work lives in Bricks
|-- channels/             # Acquisition channels
|   |-- partnerships/     # affiliate-marketing, referral-program, influencer-marketing, creator-program, education-program, public-relations
|   |-- community/        # community-forum, directory-submission, product-hunt-launch
|   |-- owned/            # employee-generated-content, email-marketing
|   +-- distribution/     # distribution-channels
|-- platforms/            # Publishing platforms
|-- strategies/            # Cross-cutting strategies
|   |-- launch/           # GTM, cold-start, PMF, indie-hacker, growth, retention, conversion, research
|   |-- brand/            # Branding, rebranding, brand-protection, content-marketing, integrated
|   |-- commercial/       # Domain, pricing, GEO, localization, paid-ads
|   +-- structure/        # SEO strategy, seo-audit, website-structure
+-- analytics/            # Compatibility pointers to Open Analytics
    |-- sources/          # Traffic and AI traffic pointers
    |-- seo/              # SEO monitoring and GSC pointers
    +-- tracking/         # GA4 tracking pointer
```

The CLI supports **recursive discovery**; `SKILL.md` files in nested directories are found automatically.

### 2.4 Folder Name vs Skill Name

**Channels, Platforms (multi-use), Analytics**: Folder name = skill `name` field. Example: `affiliate-marketing/` -> `affiliate-marketing`; `github/` -> `github`.

**Strategies**: Folder = base concept; skill name may add a suffix for function clarity. Folder and name may differ by design. Page construction belongs in [Pagina](https://github.com/kostja94/pagina), and component construction belongs in [Bricks](https://github.com/kostja94/bricks); their folders here are compatibility entries only.

| Category | Folder | Skill name | Rationale |
|----------|--------|------------|-----------|
| **Pages** | Compatibility path only | Existing `[type]-page-generator` names | New page skills belong in Pagina |
| **Strategies** | Topic (geo, cold-start, indie-hacker) | `[topic]` or `[topic]-strategy` | Folder = subject; name = full strategy identifier |
| **Channels** | = skill name | = folder | Full consistency |
| **Platforms** | = skill name | = folder | Multi-use platforms (e.g. github) use platform name only |

**Platforms naming**: Multi-use platforms (GitHub: SEO, GEO, parasite, open source) -> `[platform]` (e.g. `github`). Single-primary-use platforms -> `[platform]-[use]` (e.g. `youtube-seo`, `linkedin-posts`).

---

## 3. SKILL.md Format

### 3.1 Required Frontmatter

```yaml
---
name: skill-name
description: A description of what this skill does and when to use it.
---
```

| Field | Required | Constraints |
|-------|----------|-------------|
| `name` | Yes | Max 64 chars; lowercase letters, numbers, hyphens only; cannot start/end with hyphen; no consecutive hyphens `--` |
| `description` | Yes | Max 1024 chars; non-empty; describes what it does and when to use it |

### 3.2 name Field Rules

**Core principles** (highest priority):
1. **Content / Function / Skills consistency** - The name must accurately reflect what the skill does and covers.
2. **High search volume, most generic keywords** - Use the most common terms for SEO and skills.sh discoverability. When in conflict, Principle 1 takes precedence.

**Spec compliance**: Lowercase letters, numbers, hyphens only; 1-64 characters; no leading/trailing hyphen; no consecutive hyphens `--`.

**Category patterns**:

| Category | Pattern | Example |
|----------|---------|---------|
| Pages | Compatibility names only | New page capabilities belong in Pagina |
| SEO | Industry term (noun phrase) | schema-markup, title-tag, canonical-tag, link-building |
| Channels | `[channel]-[noun]` | referral-program, affiliate-marketing, employee-generated-content |
| Platforms | `[platform]-[suffix]` | twitter-x-posts, reddit-posts, tiktok-captions |
| Strategies | Full name, no abbreviation | generative-engine-optimization |
| Analytics | `[metric]-[action]` or tool name | traffic-analysis, google-search-console |

**Names to avoid**: Too generic (`helper`, `utils`, `tools`); vague (`seo` - prefer specific, e.g. `schema-markup`); abbreviations unclear to new users (`egc`, `geo`).

**Channel naming (partnerships)**: Use `-marketing` for disciplines (affiliate-marketing, influencer-marketing, public-relations); use `-program` for run initiatives (referral-program, creator-program, education-program). Prefer full terms over abbreviations (public-relations vs pr).

### 3.3 description Field Rules

**Must include**:
1. **WHAT**: What the skill does (specific capabilities)
2. **WHEN**: When to use it (trigger scenarios, keywords)
3. **Third person**: Description is injected into system prompt; use third person

**Recommended format**:
```yaml
description: [What it does]. Also use when the user mentions "[keyword1]," "[keyword2]," or "[keyword3]."
```

**Keyword coverage**: Include 5-12 trigger keywords; primary + synonyms + long-tail; task verbs (create, optimize, audit); tool names when relevant.

**Anti-patterns**: Too generic; missing triggers; jargon-only; first/second person; name not reflected; overlong (>300 chars).

### 3.4 Optional Frontmatter

| Field | Description | Example |
|-------|-------------|---------|
| `license` | License | `license: MIT` |
| `compatibility` | Environment requirements (<=500 chars) | `compatibility: Requires git, docker` |
| `metadata` | Arbitrary key-value pairs | `metadata:\n  version: 1.0.0` |
| `allowed-tools` | Pre-approved tools list (experimental) | `allowed-tools: Bash(git:*) Read` |

---

## 4. Body Content (Markdown Body)

The Markdown body after the frontmatter has no fixed structure. Recommended sections:

- **Step-by-step instructions**: Clear procedural guidance
- **Edge cases**: Common exceptions and handling
- **Input/output examples**: Concrete examples
- **Output format**: Expected output structure
- **Related Skills**: References to related skills

**Reference format**: Internal refs use `**skill-name**`; external refs use descriptive link text. Full rules -> [reference-rules.md](reference-rules.md).

**Progressive disclosure**: Keep main `SKILL.md` under **500 lines**; put detailed references in `references/` and link with relative paths; keep reference depth to **one level**.

### 4.1 Output Structure: Context First, Then Action

| Tier | Skills | Output |
|------|--------|--------|
| **Full structure** | Platform/channel (directories, Grokipedia, etc.) | Introduction, Importance, Methods, [Collaboration Channels], Rules, Avoid, Action |
| **Brief context** | All other skills | 1-2 sentences on what this covers and why it matters, then main output |

**Platform skills**: On **first use**, output the complete response. On **subsequent use** or when the user asks to skip, go directly to Action.

**Other skills**: On **first use**, open with 1-2 sentences context if helpful, then main output. On **subsequent use** or when user says "skip intro", go directly to the main output.

---

## 5. File Naming

**Lowercase preferred** for cross-platform compatibility. Use hyphens to separate words (e.g. `skill-authoring.md`).

**Uppercase exceptions** (tool/spec conventions):

| File | Reason |
|------|--------|
| `README.md` | GitHub, GitLab display as project homepage |
| `CONTRIBUTING.md` | GitHub contribution guidelines |
| `CHANGELOG.md` | Keep a Changelog format |
| `LICENSE` | Common convention |
| `SKILL.md` | Agent Skills specification - required for discovery |

**This repository**: Folders and skill names - lowercase, hyphens; docs - lowercase; root - README, CONTRIBUTING, CHANGELOG, LICENSE per convention.

---

## 6. skills.sh and Installation

```bash
# Install all
npx skills add owner/repo

# Install specific skills
npx skills add owner/repo --skill skill-name-1 skill-name-2

# List only (no install)
npx skills add owner/repo --list

# Non-interactive mode
npx skills add owner/repo -y
```

**Discovery paths**: Repository root; `skills/`; `skills/.curated/`; `skills/.experimental/`; agent-specific paths (e.g. `.cursor/skills/`).

**Full vs selective**: `npx skills add kostja94/marketing-skills` - all skills; `--skill robots-txt pricing-page-generator` - only specified. Remove unwanted folders from `.cursor/skills/` after install.

---

## 7. Quality Checklist

Before creating or modifying a skill, verify:

- [ ] **All content in English** - descriptions, instructions, examples, output formats
- [ ] **Single focus** - only topic-relevant content; overlapping topics use Related Skills references
- [ ] **Output structure**: Platform/channel skills use full structure with "On each invocation"; other skills include "When invoking" with brief context
- [ ] `name` follows spec (lowercase, hyphens, <=64 chars)
- [ ] `description` includes WHAT and WHEN, in third person
- [ ] `description` includes trigger keywords
- [ ] SKILL.md body < 500 lines
- [ ] Reference depth <= 1 level
- [ ] Consistent terminology
- [ ] No time-sensitive info (e.g. "before August 2025")
- [ ] References follow [reference-rules](reference-rules.md)

---

## 8. Customization

**Project Context**: Root `contextus.md` is the canonical durable-context entry. Skills consume relevant modules when present and otherwise use supplied project material without creating a parallel context format.

**Project Task Tracker**: `.cursor/project-task-tracker.md` - Track task status; agent suggests next steps.

**Using beyond Cursor & Claude**: Agent Skills-aware tools can discover installed Skills natively. Other tools can use the Markdown instructions manually, but discovery, routing, paths, and tool access depend on the host. **OpenClaw** supports AgentSkills natively: `npx skills add kostja94/marketing-skills -a openclaw`. **Full guide**: [usage.md](usage.md).

---

## 9. SkillsBench Reference (Informational)

*For reference only — one benchmark's findings; not authoritative and not a guarantee for this repository.*

[SkillsBench](https://skillsbench.ai) ([arXiv:2602.12670](https://arxiv.org/abs/2602.12670), [GitHub](https://github.com/benchflow-ai/skillsbench)) reports:

- **Measured scope** — 87 tasks across 8 domains and 18 model-harness configurations.
- **Aggregate result** — curated Skills raised average pass rate from 33.9% to 50.5% (`+16.6` percentage points).
- **Focused bundles** — Skills with at most three modules outperformed larger or exhaustive bundles in the evaluation.
- **Model tradeoff** — smaller models with Skills could match larger models without Skills in tested configurations.

Use as heuristics; your mileage may vary.

---

## 10. Reference Links

| Resource | URL |
|----------|-----|
| [README](../README.md) | Overview, installation, usage |
| [usage.md](usage.md) | All platforms - native, AGENTS.md, paste |
| Agent Skills Specification | https://agentskills.io/specification |
| skills.sh | https://skills.sh |
| Vercel skills CLI | https://github.com/vercel-labs/skills |
| SkillsBench | [Website](https://skillsbench.ai) · [arXiv:2602.12670](https://arxiv.org/abs/2602.12670) · [GitHub](https://github.com/benchflow-ai/skillsbench) |
