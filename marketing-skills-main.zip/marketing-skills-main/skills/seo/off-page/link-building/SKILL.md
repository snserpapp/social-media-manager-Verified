---
name: link-building
description: When the user wants to build backlinks, acquire links, or improve off-page SEO. Also use when the user mentions "link building," "backlinks," "off-page SEO," "link acquisition," "outreach," "guest posting," "broken link building," "link outreach," "acquire backlinks," "how to build backlinks," or "link building strategy." For profile audit, use backlink-analysis.
metadata:
  version: 1.0.1
---

# SEO Off-Page: Link Building

Guides link building strategy: acquiring quality backlinks to improve domain authority and rankings.

**When invoking**: On **first use**, if helpful, open with 1-2 sentences on what this skill covers and why it matters, then provide the main output. On **subsequent use** or when the user asks to skip, go directly to the main output.

## Scope (Off-Page SEO)

- **Link building**: Acquire backlinks from relevant, authoritative sites
- **Broken link building**: Find broken links on others' sites; suggest your content as replacement
- **Unlinked brand mentions**: Turn mentions into links via outreach
- **Guest posting**: Contribute to relevant publications; earn links
- **Journalist requests**: Respond to #JournoRequest; provide quotes/assets
- **Digital PR**: PR campaigns for backlinks and E-E-A-T — see **eeat-signals**

## Initial Assessment

**Project context:** Read root `contextus.md` when present and load only the modules relevant to this task. Without Contextus, use available project material or user-provided facts and ask for missing information; do not create a parallel context system.

Identify:
1. **Current backlink profile**: Domain authority, referring domains
2. **Target keywords**: What to rank for
3. **Linkable assets**: Research, tools, guides, data, testimonials

## Link Building Strategies

| Strategy | Description |
|----------|-------------|
| **Content marketing** | Create link-worthy content (guides, research, tools) |
| **Guest posting** | Write for relevant sites with author bio link |
| **Broken link building** | Find broken links, suggest your content as replacement |
| **Unlinked brand mentions** | Turn mentions into links via outreach |
| **Journalist requests** | Respond to #JournoRequest; provide quotes/assets |
| **Directory and curated list submission** | Get listed on directories (Taaft, Product Hunt, G2) and curated "best-of" lists; cold-start channel—see **directory-submission** for submission workflow, **cold-start-strategy** for launch plan |
| **Digital PR** | Press releases, news, expert quotes; earn authoritative links at scale |
| **Partnerships** | Partner links, co-marketing |

## Quality Over Quantity

| Factor | Good | Avoid |
|--------|------|-------|
| **Relevance** | Links from related sites | Irrelevant niches |
| **Authority** | High-quality, trusted sites | Spammy, low-quality |
| **Anchor text** | Natural, varied | Over-optimized, exact match |
| **Context** | Editorial, contextual links | Footer, sidebar link farms |

## Outreach Best Practices

- Personalize each outreach message
- Offer value (content, data, quote) before asking for link
- Follow up politely; don't spam
- Track outreach in spreadsheet or tool

## Output Format

- **Linkable asset** ideas
- **Outreach** strategy and templates
- **Target sites** (types, not specific URLs)
- **Metrics** to track (referring domains, DA, traffic)

## Related Skills

- **seo-strategy**: SEO workflow; link building is Off-Page phase
- **backlink-analysis**: Analyze current backlink profile
- **content-strategy**: Content strategy supports link building
- **keyword-research**: Target keywords inform link targets
- **cold-start-strategy**: Cold start and first-user acquisition; directory submission as part of launch
- **parasite-seo**: Parasite SEO; high-authority platforms for backlinks
- **github**: GitHub repos, gists, awesome lists for backlinks
- **directory-submission**: Directory and curated list submission--preparation, platform-specific copy, Taaft/Product Hunt/G2; use when user wants to submit product to directories or get listed on best-of roundups
- **eeat-signals**: E-E-A-T implementation; Digital PR supports authority
