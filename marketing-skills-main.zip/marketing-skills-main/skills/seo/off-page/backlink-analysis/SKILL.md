---
name: backlink-analysis
description: When the user wants to analyze backlinks, audit link profile, or identify link issues. Also use when the user mentions "backlink analysis," "backlink audit," "referring domains," "toxic links," "link profile," or "disavow file." For acquisition, use link-building.
metadata:
  version: 1.0.1
---

# SEO Off-Page: Backlink Analysis

Guides backlink profile analysis: assessing quality, identifying issues, and planning improvements.

**When invoking**: On **first use**, if helpful, open with 1–2 sentences on what this skill covers and why it matters, then provide the main output. On **subsequent use** or when the user asks to skip, go directly to the main output.

## Scope (Off-Page SEO)

- **Backlink audit**: Analyze profile; toxic links; competitive analysis
- **Authority Score**: Monitor domain/page authority; referring domains

## Initial Assessment

Identify:
1. **Domain**: Site to analyze
2. **Tool access**: SEO tools (e.g. Ahrefs, Semrush) or free alternatives
3. **Goals**: Audit for issues, competitive analysis, or growth planning

## Key Metrics

| Metric | Meaning |
|--------|---------|
| **Referring domains** | Number of unique sites linking |
| **Backlinks** | Total number of links |
| **Domain Rating (DR) / Domain Authority (DA)** | Domain strength score |
| **Anchor text distribution** | Mix of branded, generic, exact match |
| **Link velocity** | Rate of new links over time |

## Analysis Framework

### 1. Quality Assessment

- **Relevance**: Do links come from related niches?
- **Authority**: Are referring domains trusted?
- **Context**: Editorial vs. footer/sidebar links?
- **Anchor text**: Natural or over-optimized?

### 2. Risk Signals

| Signal | Action |
|--------|--------|
| **Toxic links** | Consider disavow (use cautiously) |
| **Spammy anchors** | Diversify anchor text naturally |
| **Link schemes** | Remove or disavow |
| **Sudden spike** | Investigate; may trigger penalty |

### 3. Competitive Comparison

- Compare backlink profile to competitors
- Identify link gaps (sites linking to competitors but not you)
- Find link opportunities from competitor backlinks
- See **competitor-research** for full methodology

## Disavow File

- Use only when necessary (manual penalty, toxic links)
- Submit via Google Search Console (see **google-search-console** for Links report and disavow submission)
- **Caution**: Over-disavowing can harm; use sparingly
- **References**: [Google Disavow](https://developers.google.com/search/docs/crawling-indexing/block-indexing#disavow-links)

## Output Format

- **Profile summary**: Key metrics, trends
- **Quality assessment**: Strengths and weaknesses
- **Risk signals**: Toxic or suspicious links
- **Recommendations**: Link building priorities, disavow if needed
- **Competitive insights**: Link gap opportunities

## Related Skills

- **google-search-console**: Links report, disavow file submission
- **seo-monitoring**: Backlink metrics in full SEO monitoring; quality vs quantity, referral ROI
- **link-building**: Use analysis to plan link building
- **competitor-research**: Competitor backlink analysis; link gap methodology
