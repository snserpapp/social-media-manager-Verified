---
name: medium-posts
description: When the user wants to write, publish, republish, or optimize posts on Medium.com (canonical tags, distribution, Medium SEO). Also use when the user mentions "Medium," "Medium article," "Medium story," "Medium publishing," "canonical Medium," or "publish on Medium." Not for general parasite SEO when Medium is not the target platform—use parasite-seo. For AI search visibility strategy, use generative-engine-optimization.
metadata:
  version: 1.1.0
---

# Platforms: Medium

Guides Medium publishing for parasite SEO and content distribution. Medium's domain authority helps content rank faster than on new sites; articles can reach page 1 within days. Use this skill when planning Medium content or republishing from your site.

**When invoking**: On **first use**, if helpful, open with 1–2 sentences on what this skill covers and why it matters, then provide the main output. On **subsequent use** or when the user asks to skip, go directly to the main output.

## Initial Assessment

**Project context:** Read root `contextus.md` when present and load only the modules relevant to this task. Without Contextus, use available project material or user-provided facts and ask for missing information; do not create a parallel context system.

Identify:
1. **Content**: Original or republish
2. **Canonical**: If republish, set canonical to original URL
3. **Goal**: Traffic, backlinks, AI citations

## Why Medium for Parasite SEO

| Benefit | Detail |
|---------|--------|
| **Fast rankings** | Page 1 within days vs months on own domain |
| **Authority** | Leverages Medium's domain authority |
| **AI-friendly** | Frequently cited in AI search results |
| **Backlinks** | Traffic-generating articles attract links |

## Canonical Links

When republishing: Set canonical to your original URL in Medium settings. Prevents duplicate content penalties; signals original source.

## Content Best Practices

- **Match intent**: Keyword-focused; solve problem or answer question
- **Quality**: Same quality as on your site
- **CTA**: Link to relevant site pages; don't over-promote

## Output Format

- **Title** (keyword-optimized)
- **Structure** (for original) or **canonical** setup (for republish)
- **Internal links** to site
- **CTA** placement

## Related Skills

- **parasite-seo**: Parasite SEO strategy; Medium as platform
- **article-page-generator**: Article structure for republish
- **link-building**: Medium as backlink source
- **grokipedia-recommendations**: GEO; AI search visibility
