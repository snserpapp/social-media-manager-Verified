---
name: reddit-posts
description: When the user wants to create Reddit post copy, comments, or optimize for Reddit. Also use when the user mentions "Reddit post," "subreddit," "r/," "Reddit marketing," "post to Reddit," "Reddit thread," "Reddit comment," "Reddit copy," "Reddit content," or "Reddit engagement." For Reddit ads, use reddit-ads.
metadata:
  version: 1.0.1
---

# Platforms: Reddit

Guides Reddit post and comment creation. Use for generating publish-ready posts that follow subreddit norms. Suitable for copy agents. Design agents can use for image post context.

**When invoking**: On **first use**, if helpful, open with 1-2 sentences on what this skill covers and why it matters, then provide the main output. On **subsequent use** or when the user asks to skip, go directly to the main output.

## Output: Publish-Ready Copy

This skill enables agents to generate Reddit post copy (title + body) that respects platform rules and community culture. Output is subreddit-aware and engagement-optimized.

## Core Rules

| Rule | Practice |
|------|----------|
| **90/10 principle** | 90% value, 10% promotional |
| **Self-promotion** | Max 1 in 6 posts promotional |
| **Subreddit rules** | Always check sidebar before posting |
| **Flair** | Required by many subs; wrong flair = removal |
| **Title format** | Some subs require [tags]; check top posts |

## Post Structure

### Title

- **Concise, specific, accurate**--no clickbait
- Match subreddit format (e.g., [Discussion], [Question])
- Factual; save opinions for body/comments

### Body

- **Value-first**: Lead with help, insight, or story
- **Casual, friendly tone**--like talking to a friend
- **Engagement**: Open-ended questions, invite discussion
- **Formatting**: Markdown supported; use lists, headers for readability

## Content Types

| Type | Use |
|------|-----|
| **Experience sharing** | Highest engagement; authentic stories |
| **Q&A** | Build trust; answer questions |
| **Case study** | Product value; must be transparent |
| **Tool recommendation** | Context + honest pros/cons |

## Algorithm Factors

- **Upvote/downvote ratio** matters more than raw score
- **Early engagement** weighs more; post at peak hours
- **Karma**: 100-1000+ recommended before promotional posts
- **Author interaction**: Reply to comments; boosts ranking

## Formatting (Markdown)

- **Bold**: `**text**`
- **Italic**: `*text*`
- **Lists**: `-` or `1.`
- **Links**: `[text](url)`

## Output Format

When generating Reddit copy, provide:

1. **Title** (subreddit-appropriate)
2. **Body** (value-driven, formatted)
3. **Suggested flair** (if known)
4. **Subreddit reminder**: "Verify rules before posting"

## Related Skills

- **reddit-ads**: Paid promotion on Reddit; Promoted Posts, subreddit targeting; native creative aligns with organic post style
- **twitter-x-posts**: Alternative platform
- **cold-start-strategy**: Cold start; Reddit as launch channel
- **parasite-seo**: Parasite SEO strategy; Reddit as high-authority platform
- **grokipedia-recommendations**: Wiki/encyclopedia platform for GEO and parasite SEO
- **community-forum**: Forum and community promotion; HN, Indie Hacker; community invitation tactics
- **indie-hacker-strategy**: Indie hacker first 100 users; Reddit for niche products
- **influencer-marketing**: Reddit can complement influencer outreach
